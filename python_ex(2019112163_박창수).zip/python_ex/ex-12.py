first_set = {"Monday", "Tuesday", "Wednesday", "Thursday", "Friday"}

second_set = {"Saturday", "Sunday"}

first_set.update(second_set)
print(first_set)

#2019112163 박창수
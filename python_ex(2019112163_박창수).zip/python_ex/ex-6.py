list = [2,5,4,7,6,3]

list.sort(reverse=True)
print(list[0])

#2019112163 박창수
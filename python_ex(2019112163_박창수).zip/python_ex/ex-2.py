str1 = "world"
str2 = "Dongguk"
str3 = "Programming"

print(str1[:2]+" "+str1[-2:])
print(str2[:2]+" "+str2[-2:])
print(str3[:2]+" "+str3[-2:])

#2019112163 박창수
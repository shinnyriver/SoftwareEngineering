sample_list = ['i', [1, 3, 5, 3, 7, 1, 9, 3]]
sample_list[1].reverse()
print(sample_list)


#2019112163 박창수